import java.util.List;

public class ProductorGrande extends Productor{

	public ProductorGrande(int id, String nombre, double hectareas, List<Producto> productos) {
		super(id, nombre, hectareas, productos);
		// TODO Auto-generated constructor stub
	}
	
	

}
